int lu(double **a, int n, int perm[], double tol);
