Hola :)

Per compilar el programa, utilitza la comanda "make all" al directori on esta el codi.
El programa compilat es dirà "program"
