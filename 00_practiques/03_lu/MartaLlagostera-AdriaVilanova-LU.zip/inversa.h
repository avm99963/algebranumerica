void inversa_nolu(double **a, double **inv_a, int n, int *perm);
int inversa(double **a, double **inv_a, int n, double *det_a, double tol);
