void resol(double **a, double x[], double b[], int n, int perm[]);
